#pragma once
#include "ast.h"
#include "error.h"
#include "date.h"
#include <unordered_map>
#include <functional>
#include <memory>
#include <cmath>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <ctime>

class Evaluator {
private:
    std::unordered_map<std::string, Value> globals;
    std::unordered_map<std::string, std::shared_ptr<ClassDef>> classes;
    std::unordered_map<std::string, std::shared_ptr<FunctionVal>> functions;
    std::vector<std::unordered_map<std::string, Value>> scopes;
    Value returnValue;
    bool hasReturn = false;
    Value getVar(const std::string& name, int line, int col) {
        for (auto it = scopes.rbegin(); it != scopes.rend(); ++it) {
            if (it->find(name) != it->end()) return (*it)[name];
        }
        if (globals.find(name) != globals.end()) return globals[name];
        throw NameError("Variable '" + name + "' is not defined", line, col);
    }
    void setVar(const std::string& name, const Value& val, int line, int col) {
        for (auto it = scopes.rbegin(); it != scopes.rend(); ++it) {
            if (it->find(name) != it->end()) {
                (*it)[name] = val;
                return;
            }
        }
        globals[name] = val;
    }
    void beginScope() {
        scopes.push_back({});
    }
    void endScope() {
        if (!scopes.empty()) scopes.pop_back();
    }
    bool isTruthy(const Value& v) {
        if (v.type == ValueType::BOOL) return v.boolVal;
        if (v.type == ValueType::NULLVAL) return false;
        if (v.type == ValueType::INT) return v.intVal != 0;
        if (v.type == ValueType::FLOAT) return v.floatVal != 0.0;
        if (v.type == ValueType::STR) return !v.strVal.empty();
        return true;
    }
    Value evaluateExpr(Expr* expr) {
        if (auto e = dynamic_cast<LiteralExpr*>(expr)) return e->value;
        if (auto e = dynamic_cast<VarExpr*>(expr)) return getVar(e->name, 0, 0);
        if (auto e = dynamic_cast<BinaryExpr*>(expr)) {
            if (e->op == TokenType::ASSIGN) {
                if (auto getExpr = dynamic_cast<GetExpr*>(e->left.get())) {
                    Value target = evaluateExpr(getExpr->target.get());
                    Value val = evaluateExpr(e->right.get());
                    if (target.type == ValueType::OBJECT && target.objProps) {
                        (*target.objProps)[getExpr->property] = val;
                        return val;
                    }
                }
                if (auto varExpr = dynamic_cast<VarExpr*>(e->left.get())) {
                    Value val = evaluateExpr(e->right.get());
                    setVar(varExpr->name, val, 0, 0);
                    return val;
                }
                return Value::null();
            }
            Value left = evaluateExpr(e->left.get());
            Value right = evaluateExpr(e->right.get());
            switch (e->op) {
                case TokenType::PLUS: return left + right;
                case TokenType::MINUS: return left - right;
                case TokenType::MULTIPLY: return left * right;
                case TokenType::DIVIDE: return left / right;
                case TokenType::MODULO: return left % right;
                case TokenType::BIGGER: return Value(left > right);
                case TokenType::SMALLER: return Value(left < right);
                case TokenType::EQUAL: return Value(left == right);
                case TokenType::NOT_EQUAL: return Value(!(left == right));
                case TokenType::BIGGER_EQUAL: return Value(left > right || left == right);
                case TokenType::SMALLER_EQUAL: return Value(left < right || left == right);
                case TokenType::AND: return Value(isTruthy(left) && isTruthy(right));
                case TokenType::OR: return Value(isTruthy(left) || isTruthy(right));
                default: return Value::null();
            }
        }
        if (auto e = dynamic_cast<UnaryExpr*>(expr)) {
            Value operand = evaluateExpr(e->operand.get());
            if (e->op == TokenType::NOT) return Value(!isTruthy(operand));
            if (e->op == TokenType::MINUS) {
                if (operand.type == ValueType::INT) return Value(-operand.intVal);
                if (operand.type == ValueType::FLOAT) return Value(-operand.floatVal);
            }
            return Value::null();
        }
        if (auto e = dynamic_cast<CallExpr*>(expr)) {
            std::vector<Value> args;
            for (const auto& arg : e->args) {
                args.push_back(evaluateExpr(arg.get()));
            }
            return callFunction(e->callee, args, 0, 0);
        }
        if (auto e = dynamic_cast<ArrayExpr*>(expr)) {
            std::vector<Value> elements;
            for (const auto& elem : e->elements) {
                elements.push_back(evaluateExpr(elem.get()));
            }
            return Value::makeArray(elements);
        }
        if (auto e = dynamic_cast<DictExpr*>(expr)) {
            std::unordered_map<std::string, Value> entries;
            for (const auto& [keyExpr, valExpr] : e->entries) {
                Value key = evaluateExpr(keyExpr.get());
                Value val = evaluateExpr(valExpr.get());
                entries[key.toString()] = val;
            }
            return Value::makeDict(entries);
        }
        if (auto e = dynamic_cast<IndexExpr*>(expr)) {
            Value target = evaluateExpr(e->target.get());
            Value index = evaluateExpr(e->index.get());
            if (target.type == ValueType::ARR && index.type == ValueType::INT) {
                int idx = index.intVal;
                if (idx >= 0 && idx < target.arrVal.size()) {
                    return target.arrVal[idx];
                }
            }
            return Value::null();
        }
        if (auto e = dynamic_cast<GetExpr*>(expr)) {
            Value target = evaluateExpr(e->target.get());
            if (target.type == ValueType::OBJECT && target.objProps) {
                if (target.objProps->find(e->property) != target.objProps->end()) {
                    return (*target.objProps)[e->property];
                }
            }
            return Value::null();
        }
        if (auto e = dynamic_cast<DictQueryExpr*>(expr)) {
            Value target = evaluateExpr(e->target.get());
            if (target.type == ValueType::DICT) {
                if (e->queryType == "index.val" || e->queryType == "index") {
                    if (auto q = dynamic_cast<LiteralExpr*>(e->queryValue.get())) {
                        int idx = q->value.intVal;
                        int i = 0;
                        for (const auto& [key, val] : target.dictVal) {
                            if (i == idx) return val;
                            i++;
                        }
                    }
                }
                if (e->queryType == "key.val" || e->queryType == "key") {
                    if (auto q = dynamic_cast<LiteralExpr*>(e->queryValue.get())) {
                        std::string key = q->value.strVal;
                        if (target.dictVal.find(key) != target.dictVal.end()) {
                            return target.dictVal[key];
                        }
                    }
                }
                if (e->queryType == "value.key" || e->queryType == "value") {
                    if (auto q = dynamic_cast<LiteralExpr*>(e->queryValue.get())) {
                        Value val = q->value;
                        for (const auto& [key, dictVal] : target.dictVal) {
                            if (dictVal == val) return Value(key);
                        }
                    }
                }
            }
            return Value::null();
        }
        if (auto e = dynamic_cast<DateExpr*>(expr)) {
            if (e->dateSpec == "today") {
                return Value::makeDate(DateSystem::getToday());
            }
            return Value::makeDate(e->dateSpec);
        }
        return Value::null();
    }
    Value callFunction(const std::string& name, const std::vector<Value>& args, int line, int col) {
        if (functions.find(name) != functions.end()) {
            auto fn = functions[name];
            if (fn->isBuiltin) {
                return fn->builtinFunc(args);
            }
            beginScope();
            for (size_t i = 0; i < fn->params.size() && i < args.size(); i++) {
                scopes.back()[fn->params[i].first] = args[i];
            }
            Value prevReturn = returnValue;
            bool prevHasReturn = hasReturn;
            hasReturn = false;
            evaluateStmt(fn->body.get());
            Value result = hasReturn ? returnValue : Value::null();
            hasReturn = prevHasReturn;
            returnValue = prevReturn;
            endScope();
            return result;
        }
        if (name == "write" || name == "len" || name == "type" || name == "int" || 
            name == "str" || name == "float" || name == "bool" || name == "input" ||
            name == "read_file" || name == "write_file" || name == "range" ||
            name == "append" || name == "remove" || name == "keys" || name == "values" ||
            name == "delete_file" || name == "file_exists" || name == "read_lines" ||
            name == "abs" || name == "min" || name == "max" || name == "pow" ||
            name == "sqrt" || name == "floor" || name == "ceil" || name == "round" ||
            name == "sin" || name == "cos" || name == "tan" || name == "log" ||
            name == "log10" || name == "exp" || name == "random") {
            return callBuiltin(name, const_cast<std::vector<Value>&>(args), line, col);
        }
        if (classes.find(name) != classes.end()) {
            auto cls = classes[name];
            Value obj = Value::makeObject(cls);
            if (cls->methods.find("init") != cls->methods.end()) {
                auto initVal = cls->methods["init"];
                if (initVal.type == ValueType::FUNCTION && initVal.funcDef) {
                    auto fnVal = initVal.funcDef;
                    beginScope();
                    for (size_t i = 0; i < fnVal->params.size(); i++) {
                        if (fnVal->params[i].first == "self") {
                            scopes.back()["self"] = obj;
                        } else if (i - 1 < args.size()) {
                            scopes.back()[fnVal->params[i].first] = args[i - 1];
                        }
                    }
                    evaluateStmt(fnVal->body.get());
                    endScope();
                }
            }
            return obj;
        }
        if (name.find('.') != std::string::npos) {
            std::string objName = name.substr(0, name.find('.'));
            std::string methodName = name.substr(name.find('.') + 1);
            Value obj = getVar(objName, line, col);
            if (obj.type == ValueType::OBJECT && obj.classDef) {
                if (obj.classDef->methods.find(methodName) != obj.classDef->methods.end()) {
                    auto methodVal = obj.classDef->methods[methodName];
                    if (methodVal.type == ValueType::FUNCTION && methodVal.funcDef) {
                        auto fnVal = methodVal.funcDef;
                        beginScope();
                        for (size_t i = 0; i < fnVal->params.size(); i++) {
                            if (fnVal->params[i].first == "self") {
                                scopes.back()["self"] = obj;
                            } else if (i - 1 < args.size()) {
                                scopes.back()[fnVal->params[i].first] = args[i - 1];
                            }
                        }
                        Value prevReturn = returnValue;
                        bool prevHasReturn = hasReturn;
                        hasReturn = false;
                        evaluateStmt(fnVal->body.get());
                        Value result = hasReturn ? returnValue : Value::null();
                        hasReturn = prevHasReturn;
                        returnValue = prevReturn;
                        endScope();
                        return result;
                    }
                }
            }
        }
        throw NameError("Function or class '" + name + "' is not defined", line, col);
    }
    Value callBuiltin(const std::string& name, std::vector<Value>& args, int line, int col) {
        if (name == "write") {
            if (args.empty()) {
                std::cout << std::endl;
                return Value::null();
            }
            std::string format = args[0].toString();
            size_t argIndex = 1;
            std::string result;
            for (size_t i = 0; i < format.length(); i++) {
                if (format[i] == '{' && i + 1 < format.length() && format[i + 1] == '}') {
                    if (argIndex < args.size()) {
                        result += args[argIndex].toString();
                        argIndex++;
                    } else {
                        result += "{}";
                    }
                    i++;
                } else {
                    result += format[i];
                }
            }
            std::cout << result << std::endl;
            return Value::null();
        }
        if (name == "len") {
            if (args.empty()) throw ValueError("len() requires 1 argument", line, col);
            if (args[0].type == ValueType::STR) return Value((int)args[0].strVal.length());
            if (args[0].type == ValueType::ARR) return Value((int)args[0].arrVal.size());
            if (args[0].type == ValueType::DICT) return Value((int)args[0].dictVal.size());
            if (args[0].type == ValueType::OBJECT && args[0].objProps) return Value((int)args[0].objProps->size());
            throw TypeError("len() expects str, arr, dict, or object", line, col);
        }
        if (name == "type") {
            if (args.empty()) throw ValueError("type() requires 1 argument", line, col);
            return Value(args[0].typeName());
        }
        if (name == "int") {
            if (args.empty()) throw ValueError("int() requires 1 argument", line, col);
            if (args[0].type == ValueType::INT) return args[0];
            if (args[0].type == ValueType::FLOAT) return Value((int)args[0].floatVal);
            if (args[0].type == ValueType::STR) return Value(std::stoi(args[0].strVal));
            if (args[0].type == ValueType::BOOL) return Value(args[0].boolVal ? 1 : 0);
            throw TypeError("Cannot convert " + args[0].typeName() + " to int", line, col);
        }
        if (name == "str") {
            if (args.empty()) throw ValueError("str() requires 1 argument", line, col);
            return Value(args[0].toString());
        }
        if (name == "float") {
            if (args.empty()) throw ValueError("float() requires 1 argument", line, col);
            if (args[0].type == ValueType::FLOAT) return args[0];
            if (args[0].type == ValueType::INT) return Value((double)args[0].intVal);
            if (args[0].type == ValueType::STR) return Value(std::stod(args[0].strVal));
            throw TypeError("Cannot convert " + args[0].typeName() + " to float", line, col);
        }
        if (name == "bool") {
            if (args.empty()) throw ValueError("bool() requires 1 argument", line, col);
            return Value(isTruthy(args[0]));
        }
        if (name == "input") {
            std::string prompt = args.empty() ? "" : args[0].toString();
            if (!prompt.empty()) std::cout << prompt;
            std::string input;
            std::getline(std::cin, input);
            return Value(input);
        }
        if (name == "read_file") {
            if (args.empty()) throw ValueError("read_file() requires 1 argument", line, col);
            std::ifstream file(args[0].strVal);
            if (!file.is_open()) throw FileError("Cannot open file: " + args[0].strVal);
            std::stringstream buffer;
            buffer << file.rdbuf();
            return Value(buffer.str());
        }
        if (name == "write_file") {
            if (args.size() < 2) throw ValueError("write_file() requires 2 arguments", line, col);
            std::ofstream file(args[0].strVal);
            if (!file.is_open()) throw FileError("Cannot open file: " + args[0].strVal);
            file << args[1].toString();
            file.close();
            return Value::null();
        }
        if (name == "delete_file") {
            if (args.empty()) throw ValueError("delete_file() requires 1 argument", line, col);
            if (std::remove(args[0].strVal.c_str()) != 0) {
                throw FileError("Cannot delete file: " + args[0].strVal);
            }
            return Value::null();
        }
        if (name == "file_exists") {
            if (args.empty()) throw ValueError("file_exists() requires 1 argument", line, col);
            std::ifstream file(args[0].strVal);
            return Value(file.good());
        }
        if (name == "read_lines") {
            if (args.empty()) throw ValueError("read_lines() requires 1 argument", line, col);
            std::ifstream file(args[0].strVal);
            if (!file.is_open()) throw FileError("Cannot open file: " + args[0].strVal);
            std::vector<Value> lines;
            std::string line;
            while (std::getline(file, line)) {
                lines.push_back(Value(line));
            }
            return Value::makeArray(lines);
        }
        if (name == "range") {
            if (args.size() < 2) throw ValueError("range() requires 2 arguments", line, col);
            int start = args[0].intVal;
            int end = args[1].intVal;
            std::vector<Value> result;
            for (int i = start; i < end; i++) {
                result.push_back(Value(i));
            }
            return Value::makeArray(result);
        }
        if (name == "append") {
            if (args.size() < 2) throw ValueError("append() requires 2 arguments", line, col);
            if (args[0].type == ValueType::ARR) {
                args[0].arrVal.push_back(args[1]);
                return args[0];
            }
            throw TypeError("append() expects arr as first argument", line, col);
        }
        if (name == "remove") {
            if (args.size() < 2) throw ValueError("remove() requires 2 arguments", line, col);
            if (args[0].type == ValueType::ARR && args[1].type == ValueType::INT) {
                int idx = args[1].intVal;
                if (idx >= 0 && idx < args[0].arrVal.size()) {
                    args[0].arrVal.erase(args[0].arrVal.begin() + idx);
                }
                return args[0];
            }
            throw TypeError("remove() expects arr and int", line, col);
        }
        if (name == "keys") {
            if (args.empty()) throw ValueError("keys() requires 1 argument", line, col);
            if (args[0].type == ValueType::DICT) {
                std::vector<Value> keys;
                for (const auto& [key, val] : args[0].dictVal) {
                    keys.push_back(Value(key));
                }
                return Value::makeArray(keys);
            }
            throw TypeError("keys() expects dict", line, col);
        }
        if (name == "values") {
            if (args.empty()) throw ValueError("values() requires 1 argument", line, col);
            if (args[0].type == ValueType::DICT) {
                std::vector<Value> vals;
                for (const auto& [key, val] : args[0].dictVal) {
                    vals.push_back(val);
                }
                return Value::makeArray(vals);
            }
            throw TypeError("values() expects dict", line, col);
        }
        if (name == "abs") {
            if (args.empty()) throw ValueError("abs() requires 1 argument", line, col);
            if (args[0].type == ValueType::INT) return Value(std::abs(args[0].intVal));
            if (args[0].type == ValueType::FLOAT) return Value(std::abs(args[0].floatVal));
            throw TypeError("abs() expects int or float", line, col);
        }
        if (name == "min") {
            if (args.empty()) throw ValueError("min() requires at least 1 argument", line, col);
            Value minVal = args[0];
            for (const auto& arg : args) {
                if (arg < minVal) minVal = arg;
            }
            return minVal;
        }
        if (name == "max") {
            if (args.empty()) throw ValueError("max() requires at least 1 argument", line, col);
            Value maxVal = args[0];
            for (const auto& arg : args) {
                if (arg > maxVal) maxVal = arg;
            }
            return maxVal;
        }
        if (name == "pow") {
            if (args.size() < 2) throw ValueError("pow() requires 2 arguments", line, col);
            return Value(std::pow(args[0].asDouble(), args[1].asDouble()));
        }
        if (name == "sqrt") {
            if (args.empty()) throw ValueError("sqrt() requires 1 argument", line, col);
            return Value(std::sqrt(args[0].asDouble()));
        }
        if (name == "floor") {
            if (args.empty()) throw ValueError("floor() requires 1 argument", line, col);
            return Value((int)std::floor(args[0].asDouble()));
        }
        if (name == "ceil") {
            if (args.empty()) throw ValueError("ceil() requires 1 argument", line, col);
            return Value((int)std::ceil(args[0].asDouble()));
        }
        if (name == "round") {
            if (args.empty()) throw ValueError("round() requires 1 argument", line, col);
            return Value((int)std::round(args[0].asDouble()));
        }
        if (name == "sin") {
            if (args.empty()) throw ValueError("sin() requires 1 argument", line, col);
            return Value(std::sin(args[0].asDouble()));
        }
        if (name == "cos") {
            if (args.empty()) throw ValueError("cos() requires 1 argument", line, col);
            return Value(std::cos(args[0].asDouble()));
        }
        if (name == "tan") {
            if (args.empty()) throw ValueError("tan() requires 1 argument", line, col);
            return Value(std::tan(args[0].asDouble()));
        }
        if (name == "log") {
            if (args.empty()) throw ValueError("log() requires 1 argument", line, col);
            return Value(std::log(args[0].asDouble()));
        }
        if (name == "log10") {
            if (args.empty()) throw ValueError("log10() requires 1 argument", line, col);
            return Value(std::log10(args[0].asDouble()));
        }
        if (name == "exp") {
            if (args.empty()) throw ValueError("exp() requires 1 argument", line, col);
            return Value(std::exp(args[0].asDouble()));
        }
        if (name == "random") {
            if (args.empty()) {
                return Value((int)(std::rand() % 100));
            }
            if (args.size() == 1) {
                return Value((int)(std::rand() % args[0].intVal));
            }
            if (args.size() == 2) {
                int min = args[0].intVal;
                int max = args[1].intVal;
                return Value(min + (std::rand() % (max - min + 1)));
            }
            throw ValueError("random() requires 0, 1, or 2 arguments", line, col);
        }
        throw NameError("Unknown builtin function: " + name, line, col);
    }
    void evaluateStmt(Stmt* stmt) {
        if (hasReturn) return;
        if (auto s = dynamic_cast<ExprStmt*>(stmt)) {
            evaluateExpr(s->expr.get());
            return;
        }
        if (auto s = dynamic_cast<VarDeclStmt*>(stmt)) {
            Value val = evaluateExpr(s->initializer.get());
            if (scopes.empty()) {
                globals[s->name] = val;
            } else {
                scopes.back()[s->name] = val;
            }
            return;
        }
        if (auto s = dynamic_cast<AssignStmt*>(stmt)) {
            Value val = evaluateExpr(s->value.get());
            setVar(s->name, val, 0, 0);
            return;
        }
        if (auto s = dynamic_cast<BlockStmt*>(stmt)) {
            beginScope();
            for (const auto& child : s->statements) {
                evaluateStmt(child.get());
                if (hasReturn) break;
            }
            endScope();
            return;
        }
        if (auto s = dynamic_cast<IfStmt*>(stmt)) {
            Value cond = evaluateExpr(s->condition.get());
            if (isTruthy(cond)) {
                evaluateStmt(s->thenBranch.get());
            } else if (s->elseBranch) {
                evaluateStmt(s->elseBranch.get());
            }
            return;
        }
        if (auto s = dynamic_cast<WhileStmt*>(stmt)) {
            while (isTruthy(evaluateExpr(s->condition.get()))) {
                evaluateStmt(s->body.get());
                if (hasReturn) break;
                if (s->increment) {
                    evaluateExpr(s->increment.get());
                }
            }
            return;
        }
        if (auto s = dynamic_cast<ForStmt*>(stmt)) {
            Value startVal = evaluateExpr(s->start.get());
            Value endVal = evaluateExpr(s->end.get());
            int start = startVal.intVal;
            int end = endVal.intVal;
            if (start <= end) {
                for (int i = start + 1; i < end; i++) {
                    beginScope();
                    scopes.back()[s->varName] = Value(i);
                    evaluateStmt(s->body.get());
                    endScope();
                    if (hasReturn) break;
                }
            } else {
                for (int i = start - 1; i > end; i--) {
                    beginScope();
                    scopes.back()[s->varName] = Value(i);
                    evaluateStmt(s->body.get());
                    endScope();
                    if (hasReturn) break;
                }
            }
            return;
        }
        if (auto s = dynamic_cast<FunctionStmt*>(stmt)) {
            auto fn = std::make_shared<FunctionVal>();
            fn->name = s->name;
            fn->params = s->params;
            fn->body = std::move(s->body);
            fn->isBuiltin = false;
            functions[s->name] = fn;
            return;
        }
        if (auto s = dynamic_cast<ReturnStmt*>(stmt)) {
            returnValue = evaluateExpr(s->value.get());
            hasReturn = true;
            return;
        }
        if (auto s = dynamic_cast<ClassStmt*>(stmt)) {
            auto cls = std::make_shared<ClassDef>();
            cls->name = s->name;
            for (const auto& method : s->methods) {
                auto fn = std::make_shared<FunctionVal>();
                fn->name = method->name;
                fn->params = method->params;
                fn->body = std::move(method->body);
                fn->isBuiltin = false;
                Value fnVal = Value::makeFunction(fn);
                cls->methods[method->name] = fnVal;
            }
            classes[s->name] = cls;
            return;
        }
    }
public:
    Evaluator() {
        globals.clear();
        functions.clear();
        classes.clear();
        scopes.clear();
        std::srand(std::time(nullptr));
    }
    void evaluate(Program* program) {
        for (const auto& stmt : program->statements) {
            evaluateStmt(stmt.get());
        }
    }
};