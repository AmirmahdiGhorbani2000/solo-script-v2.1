#pragma once
#include <string>
#include <variant>
#include <unordered_map>
#include <vector>
#include <memory>
#include <any>

enum class TokenType {
    WRITE, IF, ELSE, WHILE, FOR, IN, FUNCTION, RETURN,
    CLASS, OBJECT, INT, STR, FLOAT, BOOL, DATE, ARR, DICT,
    TRUE, FALSE, AND, OR, NOT,
    BIGGER, SMALLER, EQUAL, NOT_EQUAL, BIGGER_EQUAL, SMALLER_EQUAL,
    PLUS, MINUS, MULTIPLY, DIVIDE, MODULO, ASSIGN,
    LPAREN, RPAREN, LBRACE, RBRACE, LBRACKET, RBRACKET,
    COLON, DOUBLE_COLON, SEMICOLON, COMMA, DOT, RANGE,
    IDENTIFIER, NUMBER, STRING,
    AT, TILDE, HASH, NEWLINE, END, END_OF_FILE
};

struct Token {
    TokenType type;
    std::string lexeme;
    int line;
    int column;
    Token(TokenType t, std::string lex, int ln, int col) : type(t), lexeme(std::move(lex)), line(ln), column(col) {}
    Token() : type(TokenType::END_OF_FILE), lexeme(""), line(0), column(0) {}
    std::string toString() const {
        return "Token(" + std::to_string(static_cast<int>(type)) + ", '" + lexeme + "', line " + std::to_string(line) + ", col " + std::to_string(column) + ")";
    }
};

inline std::unordered_map<std::string, TokenType> keywords = {
    {"write", TokenType::WRITE}, {"if", TokenType::IF}, {"else", TokenType::ELSE},
    {"while", TokenType::WHILE}, {"for", TokenType::FOR}, {"in", TokenType::IN},
    {"function", TokenType::FUNCTION}, {"return", TokenType::RETURN},
    {"class", TokenType::CLASS}, {"object", TokenType::OBJECT},
    {"int", TokenType::INT}, {"str", TokenType::STR}, {"float", TokenType::FLOAT},
    {"bool", TokenType::BOOL}, {"date", TokenType::DATE}, {"arr", TokenType::ARR},
    {"dict", TokenType::DICT}, {"True", TokenType::TRUE}, {"False", TokenType::FALSE},
    {"and", TokenType::AND}, {"or", TokenType::OR}, {"not", TokenType::NOT},
    {"bigger", TokenType::BIGGER}, {"smaller", TokenType::SMALLER},
    {"equal", TokenType::EQUAL}, {"not_equal", TokenType::NOT_EQUAL},
    {"bigger_equal", TokenType::BIGGER_EQUAL}, {"smaller_equal", TokenType::SMALLER_EQUAL}
};

inline std::unordered_map<TokenType, std::string> tokenTypeNames = {
    {TokenType::WRITE, "WRITE"}, {TokenType::IF, "IF"}, {TokenType::ELSE, "ELSE"},
    {TokenType::WHILE, "WHILE"}, {TokenType::FOR, "FOR"}, {TokenType::IN, "IN"},
    {TokenType::FUNCTION, "FUNCTION"}, {TokenType::RETURN, "RETURN"},
    {TokenType::CLASS, "CLASS"}, {TokenType::OBJECT, "OBJECT"},
    {TokenType::INT, "INT"}, {TokenType::STR, "STR"}, {TokenType::FLOAT, "FLOAT"},
    {TokenType::BOOL, "BOOL"}, {TokenType::DATE, "DATE"}, {TokenType::ARR, "ARR"},
    {TokenType::DICT, "DICT"}, {TokenType::TRUE, "TRUE"}, {TokenType::FALSE, "FALSE"},
    {TokenType::AND, "AND"}, {TokenType::OR, "OR"}, {TokenType::NOT, "NOT"},
    {TokenType::BIGGER, "BIGGER"}, {TokenType::SMALLER, "SMALLER"},
    {TokenType::EQUAL, "EQUAL"}, {TokenType::NOT_EQUAL, "NOT_EQUAL"},
    {TokenType::BIGGER_EQUAL, "BIGGER_EQUAL"}, {TokenType::SMALLER_EQUAL, "SMALLER_EQUAL"},
    {TokenType::PLUS, "PLUS"}, {TokenType::MINUS, "MINUS"}, {TokenType::MULTIPLY, "MULTIPLY"},
    {TokenType::DIVIDE, "DIVIDE"}, {TokenType::MODULO, "MODULO"}, {TokenType::ASSIGN, "ASSIGN"},
    {TokenType::LPAREN, "LPAREN"}, {TokenType::RPAREN, "RPAREN"}, {TokenType::LBRACE, "LBRACE"},
    {TokenType::RBRACE, "RBRACE"}, {TokenType::LBRACKET, "LBRACKET"}, {TokenType::RBRACKET, "RBRACKET"},
    {TokenType::COLON, "COLON"}, {TokenType::DOUBLE_COLON, "DOUBLE_COLON"}, {TokenType::SEMICOLON, "SEMICOLON"},
    {TokenType::COMMA, "COMMA"}, {TokenType::DOT, "DOT"}, {TokenType::RANGE, "RANGE"},
    {TokenType::IDENTIFIER, "IDENTIFIER"}, {TokenType::NUMBER, "NUMBER"}, {TokenType::STRING, "STRING"},
    {TokenType::AT, "AT"}, {TokenType::TILDE, "TILDE"}, {TokenType::HASH, "HASH"},
    {TokenType::NEWLINE, "NEWLINE"}, {TokenType::END, "END"}, {TokenType::END_OF_FILE, "END_OF_FILE"}
};

inline bool isLiteral(TokenType t) {
    return t == TokenType::NUMBER || t == TokenType::STRING || t == TokenType::TRUE || t == TokenType::FALSE;
}

inline bool isType(TokenType t) {
    return t == TokenType::INT || t == TokenType::STR || t == TokenType::FLOAT || 
           t == TokenType::BOOL || t == TokenType::DATE || t == TokenType::ARR || 
           t == TokenType::DICT || t == TokenType::OBJECT;
}

inline bool isOperator(TokenType t) {
    return t == TokenType::PLUS || t == TokenType::MINUS || t == TokenType::MULTIPLY || 
           t == TokenType::DIVIDE || t == TokenType::MODULO || t == TokenType::BIGGER || 
           t == TokenType::SMALLER || t == TokenType::EQUAL || t == TokenType::NOT_EQUAL || 
           t == TokenType::BIGGER_EQUAL || t == TokenType::SMALLER_EQUAL;
}

inline bool isComparison(TokenType t) {
    return t == TokenType::BIGGER || t == TokenType::SMALLER || t == TokenType::EQUAL || 
           t == TokenType::NOT_EQUAL || t == TokenType::BIGGER_EQUAL || t == TokenType::SMALLER_EQUAL;
}

inline bool isArithmetic(TokenType t) {
    return t == TokenType::PLUS || t == TokenType::MINUS || t == TokenType::MULTIPLY || 
           t == TokenType::DIVIDE || t == TokenType::MODULO;
}