#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <variant>
#include <any>
#include <functional>
#include <chrono>
#include <ctime>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <iomanip>

enum class ValueType {
    INT, STR, FLOAT, BOOL, DATE, ARR, DICT, OBJECT, FUNCTION, CLASS, NULLVAL
};

struct Stmt;
struct ClassDef;
struct ObjectVal;
struct FunctionVal;

struct Value {
    ValueType type = ValueType::NULLVAL;
    int intVal = 0;
    double floatVal = 0.0;
    bool boolVal = false;
    std::string strVal;
    std::vector<Value> arrVal;
    std::unordered_map<std::string, Value> dictVal;
    std::shared_ptr<std::unordered_map<std::string, Value>> objProps;
    std::shared_ptr<ClassDef> classDef;
    std::shared_ptr<FunctionVal> funcDef;
    std::string dateStr;
    Value() {}
    Value(int v) : type(ValueType::INT), intVal(v) {}
    Value(double v) : type(ValueType::FLOAT), floatVal(v) {}
    Value(bool v) : type(ValueType::BOOL), boolVal(v) {}
    Value(const std::string& v) : type(ValueType::STR), strVal(v) {}
    static Value makeArray(const std::vector<Value>& v) {
        Value val;
        val.type = ValueType::ARR;
        val.arrVal = v;
        return val;
    }
    static Value makeDict(const std::unordered_map<std::string, Value>& v) {
        Value val;
        val.type = ValueType::DICT;
        val.dictVal = v;
        return val;
    }
    static Value makeObject(std::shared_ptr<ClassDef> cls) {
        Value val;
        val.type = ValueType::OBJECT;
        val.classDef = cls;
        val.objProps = std::make_shared<std::unordered_map<std::string, Value>>();
        return val;
    }
    static Value makeFunction(std::shared_ptr<FunctionVal> fn) {
        Value val;
        val.type = ValueType::FUNCTION;
        val.funcDef = fn;
        return val;
    }
    static Value makeClass(std::shared_ptr<ClassDef> cls) {
        Value val;
        val.type = ValueType::CLASS;
        val.classDef = cls;
        return val;
    }
    static Value makeDate(const std::string& d) {
        Value val;
        val.type = ValueType::DATE;
        val.dateStr = d;
        return val;
    }
    static Value null() {
        Value val;
        val.type = ValueType::NULLVAL;
        return val;
    }
    bool isNull() const {
        return type == ValueType::NULLVAL;
    }
    bool isNumeric() const {
        return type == ValueType::INT || type == ValueType::FLOAT;
    }
    double asDouble() const {
        if (type == ValueType::INT) return intVal;
        if (type == ValueType::FLOAT) return floatVal;
        return 0.0;
    }
    std::string typeName() const {
        switch (type) {
            case ValueType::INT: return "int";
            case ValueType::STR: return "str";
            case ValueType::FLOAT: return "float";
            case ValueType::BOOL: return "bool";
            case ValueType::DATE: return "date";
            case ValueType::ARR: return "arr";
            case ValueType::DICT: return "dict";
            case ValueType::OBJECT: return "object";
            case ValueType::FUNCTION: return "function";
            case ValueType::CLASS: return "class";
            case ValueType::NULLVAL: return "null";
        }
        return "unknown";
    }
    std::string toString() const {
        switch (type) {
            case ValueType::INT: return std::to_string(intVal);
            case ValueType::FLOAT: {
                std::ostringstream oss;
                oss << std::fixed << std::setprecision(6) << floatVal;
                std::string s = oss.str();
                s.erase(s.find_last_not_of('0') + 1, std::string::npos);
                if (s.back() == '.') s.pop_back();
                return s;
            }
            case ValueType::BOOL: return boolVal ? "True" : "False";
            case ValueType::STR: return strVal;
            case ValueType::DATE: return dateStr;
            case ValueType::ARR: {
                std::string result = "{";
                for (size_t i = 0; i < arrVal.size(); i++) {
                    if (i > 0) result += ",";
                    result += arrVal[i].toString();
                }
                result += "}";
                return result;
            }
            case ValueType::DICT: {
                std::string result = "[";
                bool first = true;
                for (const auto& [key, val] : dictVal) {
                    if (!first) result += ";";
                    result += "\"" + key + "\":" + val.toString();
                    first = false;
                }
                result += "]";
                return result;
            }
            case ValueType::OBJECT: {
                std::string result = "<object>";
                if (objProps) {
                    result += "{";
                    bool first = true;
                    for (const auto& [key, val] : *objProps) {
                        if (!first) result += ",";
                        result += key + ":" + val.toString();
                        first = false;
                    }
                    result += "}";
                }
                return result;
            }
            case ValueType::FUNCTION: return "<function>";
            case ValueType::CLASS: return "<class>";
            case ValueType::NULLVAL: return "null";
        }
        return "";
    }
};

struct FunctionVal {
    std::string name;
    std::vector<std::pair<std::string, std::string>> params;
    std::unique_ptr<Stmt> body;
    std::shared_ptr<ObjectVal> closure;
    bool isBuiltin = false;
    std::function<Value(const std::vector<Value>&)> builtinFunc;
    FunctionVal() : body(nullptr) {}
};

struct ObjectVal {
    std::unordered_map<std::string, Value> props;
    std::string className;
};

struct ClassDef {
    std::string name;
    std::unordered_map<std::string, Value> methods;
    std::function<Value(const std::vector<Value>&)> constructor;
};

inline Value operator+(const Value& a, const Value& b) {
    if (a.type == ValueType::STR || b.type == ValueType::STR) {
        return Value(a.toString() + b.toString());
    }
    if (a.isNumeric() && b.isNumeric()) {
        if (a.type == ValueType::FLOAT || b.type == ValueType::FLOAT) {
            return Value(a.asDouble() + b.asDouble());
        }
        return Value(a.intVal + b.intVal);
    }
    return Value::null();
}
inline Value operator-(const Value& a, const Value& b) {
    if (a.isNumeric() && b.isNumeric()) {
        if (a.type == ValueType::FLOAT || b.type == ValueType::FLOAT) {
            return Value(a.asDouble() - b.asDouble());
        }
        return Value(a.intVal - b.intVal);
    }
    return Value::null();
}
inline Value operator*(const Value& a, const Value& b) {
    if (a.isNumeric() && b.isNumeric()) {
        if (a.type == ValueType::FLOAT || b.type == ValueType::FLOAT) {
            return Value(a.asDouble() * b.asDouble());
        }
        return Value(a.intVal * b.intVal);
    }
    return Value::null();
}
inline Value operator/(const Value& a, const Value& b) {
    if (a.isNumeric() && b.isNumeric() && b.asDouble() != 0) {
        if (a.type == ValueType::FLOAT || b.type == ValueType::FLOAT) {
            return Value(a.asDouble() / b.asDouble());
        }
        return Value(a.intVal / b.intVal);
    }
    return Value::null();
}
inline Value operator%(const Value& a, const Value& b) {
    if (a.type == ValueType::INT && b.type == ValueType::INT && b.intVal != 0) {
        return Value(a.intVal % b.intVal);
    }
    if (a.isNumeric() && b.isNumeric() && b.asDouble() != 0) {
        return Value(std::fmod(a.asDouble(), b.asDouble()));
    }
    return Value::null();
}
inline bool operator==(const Value& a, const Value& b) {
    if (a.type != b.type) {
        if (a.isNumeric() && b.isNumeric()) {
            return a.asDouble() == b.asDouble();
        }
        return false;
    }
    switch (a.type) {
        case ValueType::INT: return a.intVal == b.intVal;
        case ValueType::FLOAT: return a.floatVal == b.floatVal;
        case ValueType::BOOL: return a.boolVal == b.boolVal;
        case ValueType::STR: return a.strVal == b.strVal;
        case ValueType::DATE: return a.dateStr == b.dateStr;
        case ValueType::NULLVAL: return true;
        default: return false;
    }
}
inline bool operator>(const Value& a, const Value& b) {
    if (a.isNumeric() && b.isNumeric()) return a.asDouble() > b.asDouble();
    if (a.type == ValueType::STR && b.type == ValueType::STR) return a.strVal > b.strVal;
    return false;
}
inline bool operator<(const Value& a, const Value& b) {
    if (a.isNumeric() && b.isNumeric()) return a.asDouble() < b.asDouble();
    if (a.type == ValueType::STR && b.type == ValueType::STR) return a.strVal < b.strVal;
    return false;
}