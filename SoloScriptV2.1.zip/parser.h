#pragma once
#include "ast.h"
#include "error.h"
#include <vector>
#include <memory>
#include <stdexcept>

class Parser {
private:
    std::vector<Token> tokens;
    size_t current = 0;
    bool isAtEnd() const {
        return tokens[current].type == TokenType::END_OF_FILE;
    }
    Token peek() const {
        return tokens[current];
    }
    Token previous() const {
        return tokens[current - 1];
    }
    Token advance() {
        if (!isAtEnd()) current++;
        return previous();
    }
    bool check(TokenType type) const {
        if (isAtEnd()) return false;
        return peek().type == type;
    }
    bool match(TokenType type) {
        if (check(type)) {
            advance();
            return true;
        }
        return false;
    }
    Token consume(TokenType type, const std::string& message) {
        if (check(type)) return advance();
        throw ParseError(message, peek().line, peek().column, peek().lexeme);
    }
    std::vector<std::pair<std::string, std::string>> parseParams() {
        std::vector<std::pair<std::string, std::string>> params;
        if (!check(TokenType::RPAREN)) {
            do {
                if (match(TokenType::TILDE)) {
                    consume(TokenType::DOUBLE_COLON, "Expected '::' after '~'");
                    TokenType typeTok = advance().type;
                    std::string typeName = tokenTypeNames[typeTok];
                    params.push_back({"self", typeName});
                } else {
                    std::string paramName = consume(TokenType::IDENTIFIER, "Expected parameter name").lexeme;
                    consume(TokenType::DOUBLE_COLON, "Expected '::' before parameter type");
                    TokenType typeTok = advance().type;
                    std::string typeName = tokenTypeNames[typeTok];
                    params.push_back({paramName, typeName});
                }
            } while (match(TokenType::COMMA));
        }
        consume(TokenType::RPAREN, "Expected ')' after parameters");
        return params;
    }
    std::unique_ptr<Expr> parseExpression() {
        return parseOr();
    }
    std::unique_ptr<Expr> parseOr() {
        auto expr = parseAnd();
        while (match(TokenType::OR)) {
            TokenType op = previous().type;
            auto right = parseAnd();
            expr = std::make_unique<BinaryExpr>(std::move(expr), op, std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseAnd() {
        auto expr = parseAssignment();
        while (match(TokenType::AND)) {
            TokenType op = previous().type;
            auto right = parseAssignment();
            expr = std::make_unique<BinaryExpr>(std::move(expr), op, std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseAssignment() {
        auto expr = parseComparison();
        if (match(TokenType::ASSIGN)) {
            TokenType op = previous().type;
            auto value = parseAssignment();
            return std::make_unique<BinaryExpr>(std::move(expr), op, std::move(value));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseComparison() {
        auto expr = parseArithmetic();
        while (isComparison(peek().type)) {
            TokenType op = advance().type;
            auto right = parseArithmetic();
            expr = std::make_unique<BinaryExpr>(std::move(expr), op, std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseArithmetic() {
        auto expr = parseUnary();
        while (isArithmetic(peek().type)) {
            TokenType op = advance().type;
            auto right = parseUnary();
            expr = std::make_unique<BinaryExpr>(std::move(expr), op, std::move(right));
        }
        return expr;
    }
    std::unique_ptr<Expr> parseUnary() {
        if (match(TokenType::NOT) || match(TokenType::MINUS)) {
            TokenType op = previous().type;
            auto operand = parseUnary();
            return std::make_unique<UnaryExpr>(op, std::move(operand));
        }
        return parsePrimary();
    }
    std::unique_ptr<Expr> parsePrimary() {
        if (match(TokenType::NUMBER)) {
            std::string num = previous().lexeme;
            if (num.find('.') != std::string::npos) {
                return std::make_unique<LiteralExpr>(Value(std::stod(num)));
            }
            return std::make_unique<LiteralExpr>(Value(std::stoi(num)));
        }
        if (match(TokenType::STRING)) {
            return std::make_unique<LiteralExpr>(Value(previous().lexeme));
        }
        if (match(TokenType::TRUE)) {
            return std::make_unique<LiteralExpr>(Value(true));
        }
        if (match(TokenType::FALSE)) {
            return std::make_unique<LiteralExpr>(Value(false));
        }
        if (match(TokenType::TILDE)) {
            if (match(TokenType::IDENTIFIER)) {
                std::string prop = previous().lexeme;
                return std::make_unique<GetExpr>(std::make_unique<VarExpr>("self"), prop);
            }
            throw ParseError("Expected property name after '~'", peek().line, peek().column, peek().lexeme);
        }
        if (match(TokenType::IDENTIFIER)) {
            std::string name = previous().lexeme;
            if (match(TokenType::LPAREN)) {
                std::vector<std::unique_ptr<Expr>> args;
                if (!check(TokenType::RPAREN)) {
                    do {
                        args.push_back(parseExpression());
                    } while (match(TokenType::COMMA));
                }
                consume(TokenType::RPAREN, "Expected ')' after arguments");
                return std::make_unique<CallExpr>(name, std::move(args));
            }
            if (match(TokenType::LBRACKET)) {
                auto index = parseExpression();
                consume(TokenType::RBRACKET, "Expected ']' after array index");
                return std::make_unique<IndexExpr>(std::make_unique<VarExpr>(name), std::move(index));
            }
            if (match(TokenType::LBRACE)) {
                return parseDictQuery(std::make_unique<VarExpr>(name));
            }
            if (match(TokenType::DOT)) {
                std::string prop = consume(TokenType::IDENTIFIER, "Expected property name after '.'").lexeme;
                if (match(TokenType::LPAREN)) {
                    std::vector<std::unique_ptr<Expr>> args;
                    if (!check(TokenType::RPAREN)) {
                        do {
                            args.push_back(parseExpression());
                        } while (match(TokenType::COMMA));
                    }
                    consume(TokenType::RPAREN, "Expected ')' after method arguments");
                    return std::make_unique<CallExpr>(name + "." + prop, std::move(args));
                }
                return std::make_unique<GetExpr>(std::make_unique<VarExpr>(name), prop);
            }
            return std::make_unique<VarExpr>(name);
        }
        if (match(TokenType::LPAREN)) {
            auto expr = parseExpression();
            consume(TokenType::RPAREN, "Expected ')' after expression");
            return expr;
        }
        if (match(TokenType::LBRACE)) {
            std::vector<std::unique_ptr<Expr>> elements;
            if (!check(TokenType::RBRACE)) {
                do {
                    elements.push_back(parseExpression());
                } while (match(TokenType::COMMA));
            }
            consume(TokenType::RBRACE, "Expected '}' after array");
            return std::make_unique<ArrayExpr>(std::move(elements));
        }
        if (match(TokenType::LBRACKET)) {
            std::vector<std::pair<std::unique_ptr<Expr>, std::unique_ptr<Expr>>> entries;
            if (!check(TokenType::RBRACKET)) {
                do {
                    auto key = parseExpression();
                    consume(TokenType::COLON, "Expected ':' in dict entry");
                    auto val = parseExpression();
                    entries.push_back({std::move(key), std::move(val)});
                } while (match(TokenType::SEMICOLON));
            }
            consume(TokenType::RBRACKET, "Expected ']' after dict");
            return std::make_unique<DictExpr>(std::move(entries));
        }
        if (match(TokenType::AT)) {
            if (match(TokenType::IDENTIFIER)) {
                return std::make_unique<DateExpr>(previous().lexeme);
            }
            throw ParseError("Expected date specifier after @", peek().line, peek().column, peek().lexeme);
        }
        throw ParseError("Unexpected token: " + peek().lexeme, peek().line, peek().column, peek().lexeme);
    }
    std::unique_ptr<Expr> parseDictQuery(std::unique_ptr<Expr> target) {
        if (match(TokenType::IDENTIFIER)) {
            std::string queryType = previous().lexeme;
            consume(TokenType::LPAREN, "Expected '(' in dict query");
            auto queryValue = parseExpression();
            consume(TokenType::RPAREN, "Expected ')' in dict query");
            if (match(TokenType::DOT)) {
                if (match(TokenType::IDENTIFIER)) {
                    std::string resultType = previous().lexeme;
                    consume(TokenType::RBRACE, "Expected '}' after dict query");
                    return std::make_unique<DictQueryExpr>(std::move(target), queryType + "." + resultType, std::move(queryValue));
                }
            } else if (match(TokenType::RBRACE)) {
                return std::make_unique<DictQueryExpr>(std::move(target), queryType, std::move(queryValue));
            }
        } else if (match(TokenType::STRING)) {
            std::string key = previous().lexeme;
            if (match(TokenType::DOT)) {
                if (match(TokenType::IDENTIFIER)) {
                    std::string resultType = previous().lexeme;
                    consume(TokenType::RBRACE, "Expected '}' after dict query");
                    return std::make_unique<DictQueryExpr>(std::move(target), "key." + resultType, std::make_unique<LiteralExpr>(Value(key)));
                }
            } else if (match(TokenType::RBRACE)) {
                return std::make_unique<DictQueryExpr>(std::move(target), "key", std::make_unique<LiteralExpr>(Value(key)));
            }
        } else if (match(TokenType::NUMBER)) {
            std::string num = previous().lexeme;
            int idx = std::stoi(num);
            if (match(TokenType::DOT)) {
                if (match(TokenType::IDENTIFIER)) {
                    std::string resultType = previous().lexeme;
                    consume(TokenType::RBRACE, "Expected '}' after dict query");
                    return std::make_unique<DictQueryExpr>(std::move(target), "value." + resultType, std::make_unique<LiteralExpr>(Value(idx)));
                }
            } else if (match(TokenType::RBRACE)) {
                return std::make_unique<IndexExpr>(std::move(target), std::make_unique<LiteralExpr>(Value(idx)));
            }
        }
        throw ParseError("Invalid dict query syntax", peek().line, peek().column, peek().lexeme);
    }
    std::unique_ptr<Stmt> parseStatement() {
        if (match(TokenType::WRITE)) {
            consume(TokenType::LPAREN, "Expected '(' after 'write'");
            auto expr = parseExpression();
            std::vector<std::unique_ptr<Expr>> args;
            args.push_back(std::move(expr));
            while (match(TokenType::COMMA)) {
                args.push_back(parseExpression());
            }
            consume(TokenType::RPAREN, "Expected ')' after write arguments");
            return std::make_unique<ExprStmt>(std::make_unique<CallExpr>("write", std::move(args)));
        }
        if (isType(peek().type)) {
            TokenType typeTok = advance().type;
            std::string typeName = tokenTypeNames[typeTok];
            std::string varName = consume(TokenType::IDENTIFIER, "Expected variable name").lexeme;
            consume(TokenType::ASSIGN, "Expected '=' in variable declaration");
            auto initializer = parseExpression();
            return std::make_unique<VarDeclStmt>(typeName, varName, std::move(initializer));
        }
        if (match(TokenType::OBJECT)) {
            std::string objName = consume(TokenType::IDENTIFIER, "Expected object name").lexeme;
            consume(TokenType::ASSIGN, "Expected '=' in object creation");
            std::string className = consume(TokenType::IDENTIFIER, "Expected class name").lexeme;
            consume(TokenType::LPAREN, "Expected '(' after class name");
            std::vector<std::unique_ptr<Expr>> args;
            if (!check(TokenType::RPAREN)) {
                do {
                    args.push_back(parseExpression());
                } while (match(TokenType::COMMA));
            }
            consume(TokenType::RPAREN, "Expected ')' after constructor arguments");
            return std::make_unique<VarDeclStmt>("object", objName, std::make_unique<CallExpr>(className, std::move(args)));
        }
        if (match(TokenType::IF)) {
            auto condition = parseExpression();
            consume(TokenType::COLON, "Expected ':' after if condition");
            auto thenBranch = parseBlock();
            std::unique_ptr<Stmt> elseBranch = nullptr;
            if (match(TokenType::ELSE)) {
                consume(TokenType::COLON, "Expected ':' after else");
                elseBranch = parseBlock();
            }
            return std::make_unique<IfStmt>(std::move(condition), std::move(thenBranch), std::move(elseBranch));
        }
        if (match(TokenType::WHILE)) {
            consume(TokenType::LPAREN, "Expected '(' after while");
            auto condition = parseExpression();
            std::unique_ptr<Expr> increment = nullptr;
            if (match(TokenType::COMMA)) {
                increment = parseExpression();
            }
            consume(TokenType::RPAREN, "Expected ')' after while condition");
            consume(TokenType::COLON, "Expected ':' after while");
            auto body = parseBlock();
            return std::make_unique<WhileStmt>(std::move(condition), std::move(increment), std::move(body));
        }
        if (match(TokenType::FOR)) {
            std::string varName = consume(TokenType::IDENTIFIER, "Expected loop variable").lexeme;
            consume(TokenType::IN, "Expected 'in' in for loop");
            auto start = parseExpression();
            consume(TokenType::RANGE, "Expected '...' in for loop");
            auto end = parseExpression();
            consume(TokenType::COLON, "Expected ':' after for loop");
            auto body = parseBlock();
            return std::make_unique<ForStmt>(varName, std::move(start), std::move(end), std::move(body));
        }
        if (match(TokenType::FUNCTION)) {
            std::string funcName = consume(TokenType::IDENTIFIER, "Expected function name").lexeme;
            consume(TokenType::LPAREN, "Expected '(' after function name");
            auto params = parseParams();
            consume(TokenType::COLON, "Expected ':' after function");
            auto body = parseBlock();
            return std::make_unique<FunctionStmt>(funcName, std::move(params), std::move(body));
        }
        if (match(TokenType::RETURN)) {
            auto value = parseExpression();
            return std::make_unique<ReturnStmt>(std::move(value));
        }
        if (match(TokenType::CLASS)) {
            std::string className = consume(TokenType::IDENTIFIER, "Expected class name").lexeme;
            consume(TokenType::COLON, "Expected ':' after class name");
            std::vector<std::unique_ptr<FunctionStmt>> methods;
            while (!check(TokenType::END_OF_FILE) && !check(TokenType::END)) {
                if (match(TokenType::FUNCTION)) {
                    std::string methodName = consume(TokenType::IDENTIFIER, "Expected method name").lexeme;
                    consume(TokenType::LPAREN, "Expected '(' after method name");
                    auto params = parseParams();
                    consume(TokenType::COLON, "Expected ':' after method");
                    auto body = parseBlock();
                    methods.push_back(std::make_unique<FunctionStmt>(methodName, std::move(params), std::move(body)));
                } else {
                    break;
                }
            }
            if (match(TokenType::END)) {
                
            }
            return std::make_unique<ClassStmt>(className, std::move(methods));
        }
        if (match(TokenType::TILDE)) {
            std::string prop = consume(TokenType::IDENTIFIER, "Expected property name after '~'").lexeme;
            consume(TokenType::ASSIGN, "Expected '=' after '~property'");
            auto value = parseExpression();
            return std::make_unique<ExprStmt>(std::make_unique<BinaryExpr>(std::make_unique<GetExpr>(std::make_unique<VarExpr>("self"), prop), TokenType::ASSIGN, std::move(value)));
        }
        if (match(TokenType::IDENTIFIER)) {
            std::string name = previous().lexeme;
            if (match(TokenType::LPAREN)) {
                std::vector<std::unique_ptr<Expr>> args;
                if (!check(TokenType::RPAREN)) {
                    do {
                        args.push_back(parseExpression());
                    } while (match(TokenType::COMMA));
                }
                consume(TokenType::RPAREN, "Expected ')' after arguments");
                return std::make_unique<ExprStmt>(std::make_unique<CallExpr>(name, std::move(args)));
            }
            if (match(TokenType::DOT)) {
                std::string prop = consume(TokenType::IDENTIFIER, "Expected property name after '.'").lexeme;
                if (match(TokenType::LPAREN)) {
                    std::vector<std::unique_ptr<Expr>> args;
                    if (!check(TokenType::RPAREN)) {
                        do {
                            args.push_back(parseExpression());
                        } while (match(TokenType::COMMA));
                    }
                    consume(TokenType::RPAREN, "Expected ')' after method arguments");
                    return std::make_unique<ExprStmt>(std::make_unique<CallExpr>(name + "." + prop, std::move(args)));
                }
                if (match(TokenType::ASSIGN)) {
                    auto value = parseExpression();
                    return std::make_unique<ExprStmt>(std::make_unique<BinaryExpr>(std::make_unique<GetExpr>(std::make_unique<VarExpr>(name), prop), TokenType::ASSIGN, std::move(value)));
                }
                throw ParseError("Expected '(' or '=' after property", peek().line, peek().column, peek().lexeme);
            }
            if (match(TokenType::ASSIGN)) {
                auto value = parseExpression();
                return std::make_unique<AssignStmt>(name, std::move(value));
            }
            throw ParseError("Unexpected identifier: " + name, peek().line, peek().column, peek().lexeme);
        }
        throw ParseError("Unexpected token: " + peek().lexeme, peek().line, peek().column, peek().lexeme);
    }
    std::unique_ptr<Stmt> parseBlock() {
        std::vector<std::unique_ptr<Stmt>> statements;
        while (!isAtEnd()) {
            if (peek().type == TokenType::END) {
                advance();
                break;
            }
            if (peek().type == TokenType::ELSE) {
                break;
            }
            if (peek().type == TokenType::NEWLINE) {
                advance();
                continue;
            }
            statements.push_back(parseStatement());
        }
        return std::make_unique<BlockStmt>(std::move(statements));
    }
public:
    explicit Parser(std::vector<Token> toks) : tokens(std::move(toks)) {}
    std::unique_ptr<Program> parse() {
        std::vector<std::unique_ptr<Stmt>> statements;
        while (!isAtEnd()) {
            if (peek().type == TokenType::NEWLINE) {
                advance();
                continue;
            }
            statements.push_back(parseStatement());
        }
        return std::make_unique<Program>(std::move(statements));
    }
};