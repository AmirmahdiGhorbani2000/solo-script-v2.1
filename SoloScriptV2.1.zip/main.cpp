#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include "lexer.h"
#include "parser.h"
#include "evaluator.h"

int main() {
    std::cout << "\033[1;36mSoloScript v2.1.0\033[0m" << std::endl;
    std::cout << "\033[1;30m—————————————————————————————————————————————\033[0m" << std::endl;
    std::cout << "\033[1;33mFileName: \033[0m";
    std::string filename;
    std::getline(std::cin, filename);
    std::system("clear");
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "\033[1;31mError: Cannot open file '" << filename << "'\033[0m" << std::endl;
        return 1;
    }
    std::stringstream buffer;
    buffer << file.rdbuf();
    std::string source = buffer.str();
    file.close();
    try {
        Lexer lexer(source);
        auto tokens = lexer.tokenize();
        Parser parser(tokens);
        auto ast = parser.parse();
        Evaluator evaluator;
        evaluator.evaluate(ast.get());
    } catch (const SoloError& e) {
        std::cerr << "\033[1;31m" << e.format() << "\033[0m" << std::endl;
        return 1;
    } catch (const std::exception& e) {
        std::cerr << "\033[1;31mError: " << e.what() << "\033[0m" << std::endl;
        return 1;
    }
    return 0;
}