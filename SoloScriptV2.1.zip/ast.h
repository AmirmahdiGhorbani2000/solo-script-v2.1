#pragma once
#include "token.h"
#include "values.h"
#include <memory>
#include <vector>
#include <string>

struct Expr {
    virtual ~Expr() = default;
};
struct Stmt {
    virtual ~Stmt() = default;
};
struct LiteralExpr : Expr {
    Value value;
    LiteralExpr(const Value& v) : value(v) {}
};
struct VarExpr : Expr {
    std::string name;
    VarExpr(const std::string& n) : name(n) {}
};
struct BinaryExpr : Expr {
    std::unique_ptr<Expr> left;
    std::unique_ptr<Expr> right;
    TokenType op;
    BinaryExpr(std::unique_ptr<Expr> l, TokenType o, std::unique_ptr<Expr> r)
        : left(std::move(l)), right(std::move(r)), op(o) {}
};
struct UnaryExpr : Expr {
    TokenType op;
    std::unique_ptr<Expr> operand;
    UnaryExpr(TokenType o, std::unique_ptr<Expr> e) : op(o), operand(std::move(e)) {}
};
struct CallExpr : Expr {
    std::string callee;
    std::vector<std::unique_ptr<Expr>> args;
    CallExpr(const std::string& c, std::vector<std::unique_ptr<Expr>> a)
        : callee(c), args(std::move(a)) {}
};
struct ArrayExpr : Expr {
    std::vector<std::unique_ptr<Expr>> elements;
    ArrayExpr(std::vector<std::unique_ptr<Expr>> e) : elements(std::move(e)) {}
};
struct DictExpr : Expr {
    std::vector<std::pair<std::unique_ptr<Expr>, std::unique_ptr<Expr>>> entries;
    DictExpr(std::vector<std::pair<std::unique_ptr<Expr>, std::unique_ptr<Expr>>> e)
        : entries(std::move(e)) {}
};
struct IndexExpr : Expr {
    std::unique_ptr<Expr> target;
    std::unique_ptr<Expr> index;
    IndexExpr(std::unique_ptr<Expr> t, std::unique_ptr<Expr> i)
        : target(std::move(t)), index(std::move(i)) {}
};
struct GetExpr : Expr {
    std::unique_ptr<Expr> target;
    std::string property;
    GetExpr(std::unique_ptr<Expr> t, const std::string& p)
        : target(std::move(t)), property(p) {}
};
struct DictQueryExpr : Expr {
    std::unique_ptr<Expr> target;
    std::string queryType;
    std::unique_ptr<Expr> queryValue;
    DictQueryExpr(std::unique_ptr<Expr> t, const std::string& qt, std::unique_ptr<Expr> qv)
        : target(std::move(t)), queryType(qt), queryValue(std::move(qv)) {}
};
struct DateExpr : Expr {
    std::string dateSpec;
    DateExpr(const std::string& d) : dateSpec(d) {}
};
struct ExprStmt : Stmt {
    std::unique_ptr<Expr> expr;
    ExprStmt(std::unique_ptr<Expr> e) : expr(std::move(e)) {}
};
struct VarDeclStmt : Stmt {
    std::string typeName;
    std::string name;
    std::unique_ptr<Expr> initializer;
    VarDeclStmt(const std::string& t, const std::string& n, std::unique_ptr<Expr> init)
        : typeName(t), name(n), initializer(std::move(init)) {}
};
struct AssignStmt : Stmt {
    std::string name;
    std::unique_ptr<Expr> value;
    AssignStmt(const std::string& n, std::unique_ptr<Expr> v)
        : name(n), value(std::move(v)) {}
};
struct IndexAssignStmt : Stmt {
    std::unique_ptr<Expr> target;
    std::unique_ptr<Expr> index;
    std::unique_ptr<Expr> value;
    IndexAssignStmt(std::unique_ptr<Expr> t, std::unique_ptr<Expr> i, std::unique_ptr<Expr> v)
        : target(std::move(t)), index(std::move(i)), value(std::move(v)) {}
};
struct BlockStmt : Stmt {
    std::vector<std::unique_ptr<Stmt>> statements;
    BlockStmt(std::vector<std::unique_ptr<Stmt>> s) : statements(std::move(s)) {}
};
struct IfStmt : Stmt {
    std::unique_ptr<Expr> condition;
    std::unique_ptr<Stmt> thenBranch;
    std::unique_ptr<Stmt> elseBranch;
    IfStmt(std::unique_ptr<Expr> c, std::unique_ptr<Stmt> t, std::unique_ptr<Stmt> e)
        : condition(std::move(c)), thenBranch(std::move(t)), elseBranch(std::move(e)) {}
};
struct WhileStmt : Stmt {
    std::unique_ptr<Expr> condition;
    std::unique_ptr<Expr> increment;
    std::unique_ptr<Stmt> body;
    WhileStmt(std::unique_ptr<Expr> c, std::unique_ptr<Expr> inc, std::unique_ptr<Stmt> b)
        : condition(std::move(c)), increment(std::move(inc)), body(std::move(b)) {}
};
struct ForStmt : Stmt {
    std::string varName;
    std::unique_ptr<Expr> start;
    std::unique_ptr<Expr> end;
    std::unique_ptr<Stmt> body;
    ForStmt(const std::string& v, std::unique_ptr<Expr> s, std::unique_ptr<Expr> e, std::unique_ptr<Stmt> b)
        : varName(v), start(std::move(s)), end(std::move(e)), body(std::move(b)) {}
};
struct FunctionStmt : Stmt {
    std::string name;
    std::vector<std::pair<std::string, std::string>> params;
    std::unique_ptr<Stmt> body;
    FunctionStmt(const std::string& n, std::vector<std::pair<std::string, std::string>> p, std::unique_ptr<Stmt> b)
        : name(n), params(std::move(p)), body(std::move(b)) {}
};
struct ReturnStmt : Stmt {
    std::unique_ptr<Expr> value;
    ReturnStmt(std::unique_ptr<Expr> v) : value(std::move(v)) {}
};
struct ClassStmt : Stmt {
    std::string name;
    std::vector<std::unique_ptr<FunctionStmt>> methods;
    ClassStmt(const std::string& n, std::vector<std::unique_ptr<FunctionStmt>> m)
        : name(n), methods(std::move(m)) {}
};
struct Program {
    std::vector<std::unique_ptr<Stmt>> statements;
    Program(std::vector<std::unique_ptr<Stmt>> s) : statements(std::move(s)) {}
};