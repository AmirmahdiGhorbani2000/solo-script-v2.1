#pragma once
#include "token.h"
#include "error.h"
#include <vector>
#include <string>
#include <cctype>
#include <sstream>

class Lexer {
private:
    std::string source;
    size_t pos = 0;
    int line = 1;
    int column = 1;
    char peek() const {
        if (pos >= source.length()) return '\0';
        return source[pos];
    }
    char peekNext() const {
        if (pos + 1 >= source.length()) return '\0';
        return source[pos + 1];
    }
    char peekNextNext() const {
        if (pos + 2 >= source.length()) return '\0';
        return source[pos + 2];
    }
    char advance() {
        char c = source[pos++];
        if (c == '\n') {
            line++;
            column = 1;
        } else {
            column++;
        }
        return c;
    }
    bool isAtEnd() const {
        return pos >= source.length();
    }
    void skipWhitespace() {
        while (!isAtEnd()) {
            char c = peek();
            if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
                advance();
            } else {
                break;
            }
        }
    }
    void skipComment() {
        while (!isAtEnd() && peek() != '\n') {
            advance();
        }
    }
    Token makeToken(TokenType type) {
        int ln = line;
        int col = column;
        std::string lex = std::string(1, advance());
        return Token(type, lex, ln, col);
    }
    Token number() {
        int ln = line;
        int col = column;
        std::string num;
        bool isFloat = false;
        while (!isAtEnd() && std::isdigit(peek())) {
            num += advance();
        }
        if (!isAtEnd() && peek() == '.' && peekNext() != '.' && std::isdigit(peekNext())) {
            isFloat = true;
            num += advance();
            while (!isAtEnd() && std::isdigit(peek())) {
                num += advance();
            }
        }
        return Token(TokenType::NUMBER, num, ln, col);
    }
    Token identifier() {
        int ln = line;
        int col = column;
        std::string ident;
        while (!isAtEnd() && (std::isalnum(peek()) || peek() == '_')) {
            ident += advance();
        }
        auto it = keywords.find(ident);
        if (it != keywords.end()) {
            return Token(it->second, ident, ln, col);
        }
        return Token(TokenType::IDENTIFIER, ident, ln, col);
    }
    Token string() {
        int ln = line;
        int col = column;
        advance();
        std::string str;
        while (!isAtEnd() && peek() != '"') {
            if (peek() == '\\') {
                advance();
                char escaped = advance();
                switch (escaped) {
                    case 'n': str += '\n'; break;
                    case 't': str += '\t'; break;
                    case 'r': str += '\r'; break;
                    case '\\': str += '\\'; break;
                    case '"': str += '"'; break;
                    default: str += escaped; break;
                }
            } else {
                str += advance();
            }
        }
        if (isAtEnd()) {
            throw LexError("Unterminated string", ln, col, source);
        }
        advance();
        return Token(TokenType::STRING, str, ln, col);
    }
public:
    explicit Lexer(std::string src) : source(std::move(src)) {}
    std::vector<Token> tokenize() {
        std::vector<Token> tokens;
        while (!isAtEnd()) {
            skipWhitespace();
            if (isAtEnd()) break;
            char c = peek();
            if (c == '#') {
                skipComment();
                continue;
            }
            if (std::isdigit(c)) {
                tokens.push_back(number());
                continue;
            }
            if (std::isalpha(c) || c == '_') {
                tokens.push_back(identifier());
                continue;
            }
            if (c == '"') {
                tokens.push_back(string());
                continue;
            }
            switch (c) {
                case '(': tokens.push_back(makeToken(TokenType::LPAREN)); break;
                case ')': tokens.push_back(makeToken(TokenType::RPAREN)); break;
                case '{': {
                    int ln = line;
                    int col = column;
                    if (peekNext() == 'e' && pos + 5 < source.length()) {
                        std::string temp = source.substr(pos, 5);
                        if (temp == "{end}") {
                            for (int i = 0; i < 5; i++) advance();
                            tokens.push_back(Token(TokenType::END, "{end}", ln, col));
                            break;
                        }
                    }
                    tokens.push_back(makeToken(TokenType::LBRACE));
                    break;
                }
                case '}': tokens.push_back(makeToken(TokenType::RBRACE)); break;
                case '[': tokens.push_back(makeToken(TokenType::LBRACKET)); break;
                case ']': tokens.push_back(makeToken(TokenType::RBRACKET)); break;
                case ':': {
                    int ln = line;
                    int col = column;
                    if (peekNext() == ':') {
                        advance();
                        advance();
                        tokens.push_back(Token(TokenType::DOUBLE_COLON, "::", ln, col));
                    } else {
                        advance();
                        tokens.push_back(Token(TokenType::COLON, ":", ln, col));
                    }
                    break;
                }
                case ';': tokens.push_back(makeToken(TokenType::SEMICOLON)); break;
                case ',': tokens.push_back(makeToken(TokenType::COMMA)); break;
                case '@': tokens.push_back(makeToken(TokenType::AT)); break;
                case '~': tokens.push_back(makeToken(TokenType::TILDE)); break;
                case '*': tokens.push_back(makeToken(TokenType::MULTIPLY)); break;
                case '+': tokens.push_back(makeToken(TokenType::PLUS)); break;
                case '-': tokens.push_back(makeToken(TokenType::MINUS)); break;
                case '/': tokens.push_back(makeToken(TokenType::DIVIDE)); break;
                case '%': tokens.push_back(makeToken(TokenType::MODULO)); break;
                case '=': tokens.push_back(makeToken(TokenType::ASSIGN)); break;
                case '.': {
                    int ln = line;
                    int col = column;
                    if (peekNext() == '.' && peekNextNext() == '.') {
                        advance();
                        advance();
                        advance();
                        tokens.push_back(Token(TokenType::RANGE, "...", ln, col));
                    } else {
                        advance();
                        tokens.push_back(Token(TokenType::DOT, ".", ln, col));
                    }
                    break;
                }
                default: {
                    std::string lineText;
                    std::istringstream iss(source);
                    int currentLine = 1;
                    while (std::getline(iss, lineText)) {
                        if (currentLine == line) break;
                        currentLine++;
                    }
                    throw LexError("Unexpected character: " + std::string(1, c), line, column, lineText);
                }
            }
        }
        tokens.push_back(Token(TokenType::END_OF_FILE, "", line, column));
        return tokens;
    }
};