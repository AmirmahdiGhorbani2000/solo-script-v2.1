#pragma once
#include <string>
#include <stdexcept>
#include <sstream>

class SoloError : public std::runtime_error {
public:
    std::string errorType;
    int line;
    int column;
    std::string sourceLine;
    SoloError(const std::string& type, const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : std::runtime_error(msg), errorType(type), line(ln), column(col), sourceLine(srcLine) {}
    std::string format() const {
        std::ostringstream oss;
        oss << "Error: " << errorType << " at line " << line;
        if (column > 0) oss << ", column " << column;
        oss << "\n  " << what();
        if (!sourceLine.empty()) {
            oss << "\n    " << sourceLine;
            if (column > 0) {
                oss << "\n    " << std::string(column - 1, ' ') << "^";
            }
        }
        return oss.str();
    }
};

class LexError : public SoloError {
public:
    LexError(const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : SoloError("Lexical Error", msg, ln, col, srcLine) {}
};

class ParseError : public SoloError {
public:
    ParseError(const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : SoloError("Parse Error", msg, ln, col, srcLine) {}
};

class RuntimeError : public SoloError {
public:
    RuntimeError(const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : SoloError("Runtime Error", msg, ln, col, srcLine) {}
};

class TypeError : public SoloError {
public:
    TypeError(const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : SoloError("Type Error", msg, ln, col, srcLine) {}
};

class NameError : public SoloError {
public:
    NameError(const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : SoloError("Name Error", msg, ln, col, srcLine) {}
};

class IndexError : public SoloError {
public:
    IndexError(const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : SoloError("Index Error", msg, ln, col, srcLine) {}
};

class ValueError : public SoloError {
public:
    ValueError(const std::string& msg, int ln, int col, const std::string& srcLine = "")
        : SoloError("Value Error", msg, ln, col, srcLine) {}
};

class FileError : public SoloError {
public:
    FileError(const std::string& msg)
        : SoloError("File Error", msg, 0, 0, "") {}
};