#pragma once
#include <string>
#include <chrono>
#include <ctime>
#include <sstream>
#include <iomanip>

class DateSystem {
private:
    static bool isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
    static int daysInMonth(int year, int month) {
        static const int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (month == 2 && isLeapYear(year)) return 29;
        return days[month - 1];
    }
    static long long gregorianToJalali(int gy, int gm, int gd) {
        long long d = 0;
        for (int y = 1; y < gy; y++) {
            d += isLeapYear(y) ? 366 : 365;
        }
        for (int m = 1; m < gm; m++) {
            d += daysInMonth(gy, m);
        }
        d += gd - 1;
        return d;
    }
    static void jalaliToGregorian(long long jd, int& gy, int& gm, int& gd) {
        long long d = jd;
        gy = 1;
        while (true) {
            int days = isLeapYear(gy) ? 366 : 365;
            if (d < days) break;
            d -= days;
            gy++;
        }
        gm = 1;
        while (true) {
            int days = daysInMonth(gy, gm);
            if (d < days) break;
            d -= days;
            gm++;
        }
        gd = d + 1;
    }
    static long long gregorianToJalaliDay(int gy, int gm, int gd) {
        long long jd = gregorianToJalali(gy, gm, gd);
        jd -= gregorianToJalali(622, 3, 21);
        return jd;
    }
    static void jalaliDayToDate(long long jd, int& jy, int& jm, int& jd_) {
        jd += gregorianToJalali(622, 3, 21);
        int gy, gm, gd;
        jalaliToGregorian(jd, gy, gm, gd);
        long long dayCount = gregorianToJalaliDay(gy, gm, gd);
        jy = 1;
        while (true) {
            int days = isLeapYear(jy + 621) ? 366 : 365;
            if (dayCount < days) break;
            dayCount -= days;
            jy++;
        }
        jm = 1;
        while (true) {
            int days = jm <= 6 ? 31 : (jm <= 11 ? 30 : (isLeapYear(jy + 621) ? 30 : 29));
            if (dayCount < days) break;
            dayCount -= days;
            jm++;
        }
        jd_ = dayCount + 1;
    }
public:
    static std::string getToday() {
        std::time_t t = std::time(nullptr);
        std::tm* now = std::localtime(&t);
        int gy = now->tm_year + 1900;
        int gm = now->tm_mon + 1;
        int gd = now->tm_mday;
        long long jd = gregorianToJalaliDay(gy, gm, gd);
        int jy, jm, jd_;
        jalaliDayToDate(jd, jy, jm, jd_);
        std::ostringstream oss;
        oss << jy << "." << std::setw(2) << std::setfill('0') << jm << "." << std::setw(2) << std::setfill('0') << jd_;
        return oss.str();
    }
    static std::string formatDate(const std::string& dateStr) {
        return dateStr;
    }
    static bool isValidDate(const std::string& dateStr) {
        int y, m, d;
        char dot1, dot2;
        std::istringstream iss(dateStr);
        if (!(iss >> y >> dot1 >> m >> dot2 >> d)) return false;
        if (dot1 != '.' || dot2 != '.') return false;
        if (m < 1 || m > 12) return false;
        if (d < 1) return false;
        int maxDays = m <= 6 ? 31 : (m <= 11 ? 30 : (isLeapYear(y + 621) ? 30 : 29));
        return d <= maxDays;
    }
    static std::string addDays(const std::string& dateStr, int days) {
        int y, m, d;
        char dot1, dot2;
        std::istringstream iss(dateStr);
        iss >> y >> dot1 >> m >> dot2 >> d;
        long long jd = gregorianToJalaliDay(y + 621, m, d);
        jd += days;
        int jy, jm, jd_;
        jalaliDayToDate(jd, jy, jm, jd_);
        std::ostringstream oss;
        oss << jy << "." << std::setw(2) << std::setfill('0') << jm << "." << std::setw(2) << std::setfill('0') << jd_;
        return oss.str();
    }
    static int daysBetween(const std::string& date1, const std::string& date2) {
        int y1, m1, d1, y2, m2, d2;
        char dot;
        std::istringstream iss1(date1);
        std::istringstream iss2(date2);
        iss1 >> y1 >> dot >> m1 >> dot >> d1;
        iss2 >> y2 >> dot >> m2 >> dot >> d2;
        long long jd1 = gregorianToJalaliDay(y1 + 621, m1, d1);
        long long jd2 = gregorianToJalaliDay(y2 + 621, m2, d2);
        return std::abs((int)(jd2 - jd1));
    }
    static std::string getDayOfWeek(const std::string& dateStr) {
        int y, m, d;
        char dot;
        std::istringstream iss(dateStr);
        iss >> y >> dot >> m >> dot >> d;
        long long jd = gregorianToJalaliDay(y + 621, m, d);
        static const char* days[] = {"شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"};
        return days[(jd + 1) % 7];
    }
};